CREATE DATABASE  IF NOT EXISTS `farmacia` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `farmacia`;
-- MySQL dump 10.13  Distrib 8.0.32, for Win64 (x86_64)
--
-- Host: localhost    Database: farmacia
-- ------------------------------------------------------
-- Server version	8.0.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cliente` (
  `IDCliente` int NOT NULL AUTO_INCREMENT,
  `Nome` varchar(50) NOT NULL,
  `Sexo` varchar(11) DEFAULT NULL,
  `DataNascimento` date NOT NULL,
  `EstadoCivil` varchar(20) NOT NULL,
  `CPF` varchar(14) DEFAULT NULL,
  `Telefone` varchar(16) DEFAULT NULL,
  `Email` varchar(50) NOT NULL,
  `Endereco` varchar(50) NOT NULL,
  PRIMARY KEY (`IDCliente`),
  UNIQUE KEY `CPF` (`CPF`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cliente`
--

LOCK TABLES `cliente` WRITE;
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` VALUES (2,'Paulo','Masculino','2023-04-18','SOLTEIRO','111.111.111-11','(11) 1 1111-1111','mail','okk'),(3,'Ana','Masculino','2023-04-03','DIVORCIADO','222.222.222-22','(22) 2 2222-2222','osw','sdszcs'),(4,'Lucia','Não-Binario','2023-04-18','SOLTEIRO','233.333.333-33','(33) 3 3333-3333','mail','Av de Maio'),(5,'Marcia','Feminino','1960-06-16','CASADO','595.584.584-18','(11) 0 2280-9512','Clia.60@','Rua Arica Mrim, xxx'),(6,'Maria','Feminino','1936-09-21','CASADO','38584885858','58182882281','maria','Rua Arimi'),(7,'Carlos','Masculino','2018-05-17','DIVORCIADO','123.456.789-52','(11) 2 3448-7458','mail','Endereco'),(8,'Pedro','Não-Binario','2003-05-20','CASADO','123.486.789-45','(11) 2 5254-5115','mail01','Rua Coisa'),(9,'Guilherme','Não-Binario','2017-05-17','DIVORCIADO','123.654.899-65','(12) 3 4569-8456','maik01','Rua aa');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-05-23 17:51:57
