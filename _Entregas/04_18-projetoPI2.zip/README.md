# PI-2

<details>
	<summary>Sumario</summary>

- [PI-2](#pi-2)
	- [Tela de Inicio](#tela-de-inicio)
	- [Cliente](#cliente)
		- [Cadastro](#cadastro)
		- [Consulta](#consulta)
	- [Produto](#produto)
		- [Cadastro](#cadastro-1)
		- [Consulta](#consulta-1)
	- [Relatório](#relatório)
		- [Sintetico](#sintetico)
		- [Análitico](#análitico)

</details>

## Tela de Inicio
<details open>
	<summary></summary>

![Tela de Inicio](./images/teladeinicio.png)

</details>

## Cliente


### Cadastro
<details open>
	<summary></summary>

![Tela de Inicio](./images/CLI_Cadastrar.png)

</details>

### Consulta
<details open>
	<summary></summary>

![Tela de Inicio](./images/CLI_Consultar.png)

</details>


## Produto

### Cadastro
<details open>
	<summary></summary>

![Tela de Inicio](./images/PRO_Adicionar.png)

</details>

### Consulta
<details open>
	<summary></summary>

![Tela de Inicio](./images/PRO_Consultar.png)

</details>

## Relatório

### Sintetico
<details open>
	<summary></summary>

![Tela de Inicio](./images/REL_Sintetico.png)

</details>

### Análitico
<details open>
	<summary></summary>

![Tela de Inicio](./images/REL_Analitico.png)

</details>